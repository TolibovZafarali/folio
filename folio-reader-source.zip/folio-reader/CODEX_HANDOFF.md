# Folio Reader: standalone source handoff

## What this bundle contains

This is the Windows desktop app extracted from `TolibovZafarali/any-to-pdf`, with the project rooted directly at `package.json`. Its version remains **1.1.1**. It contains the Electron main process and preload, PDF reader interface, persistent local library, updater controller, tests, Windows build/release workflows, and a local PDF test fixture.

The website and `/books` web application are not part of this project. Runtime behavior has not been changed by this move. The bundle excludes `.git`, dependencies, built interfaces, release binaries, generated PDF.js assets, environment files, and user libraries. It contains no credentials.

## First steps after extracting

1. Open the extracted directory that contains `package.json` as the repository root. Do not nest it under a new `desktop/` directory or require files from a parent project.
2. Inspect the included README, package scripts, and workflows. Use Node.js 22.13 or newer.
3. Install and validate from that directory:

   ```sh
   npm ci
   npm test
   npm run test:app
   ```

4. Run `npm start` to inspect the real app. Import a PDF, navigate to another page, close and reopen, then check the retained book/page. Verify resizing and pinning on Windows.
5. On a clean Windows test profile, run:

   ```sh
   npm run build
   npm run test:installed
   node scripts/verify-update.cjs
   ```

`test:installed` intentionally refuses to use an existing Folio Reader profile. Its Windows installation test must run on a clean runner, not a personal account with a real library. The unit/native tests use isolated temporary profiles. `test/fixtures/orwellanimalfarm.pdf` supplies the PDF used by all three library/native/installed test files.

## Configure the destination repository before releasing

The new destination is not known yet, so the original GitHub repository remains in the package metadata and updater defaults as provenance. No release should be created from those defaults in a different repository.

When the intended destination is established:

- Change `package.json` → `repository.url` to the new GitHub repository. There is no `repository.directory` because this project is already at the root.
- Change `package.json` → `build.publish` → the GitHub provider's `owner` and `repo` to that same destination. Keep the provider and tag prefix consistent with the workflow.
- Replace the original-repository installer, release, and documentation links in `README.md` and any new project documentation.
- Review `.github/workflows/desktop-check.yml` and `.github/workflows/desktop-release.yml`. They run from the project root and use the current GitHub repository for release publication. Make sure the workflow destination agrees with `build.publish`, which controls installed clients' update source.
- Keep the release assets together: installer, blockmap, `latest.yml`, and checksums. The release workflow stages a draft before publishing the complete update as latest.
- Choose a version newer than 1.1.1 only when preparing a real release; update `package.json` and its lockfile together. Match the `reader-vX.Y.Z` Git tag to that version.

The installed-app test reads its expected updater owner/repo from `package.json`, so changing repository configuration does not require hardcoded test edits.

## Preserve application identity and users' data

Keep these values and contracts stable during the repository move:

- `build.appId`: `com.folio.reader`
- `build.productName` and `app.setName(...)`: `Folio Reader`
- The Windows data directory: `%APPDATA%\Folio Reader\`
- The existing `library.json` version-1 schema, imported-PDF ID/file mapping, reading progress, pin preference, and window bounds
- Retaining application data on uninstall (`deleteAppDataOnUninstall: false`)

Do not move or erase the data directory just to reorganize source. Import copies remain separate from original files; users should retain their books and page positions across installation updates.

## Existing users do not automatically move update feeds

Already installed 1.1.1 clients contain update settings pointing to `TolibovZafarali/any-to-pdf`. They will keep polling that repository after this source is uploaded elsewhere.

A new installer built with the new destination can be installed manually over the existing app while preserving the identity/data directory above. Automatic migration instead requires a separately planned bridge release through the old update feed. Do not claim existing clients migrated merely because the new source metadata or repository changed.

## Structure

- `main.cjs`, `preload.cjs`, `trusted-entry.cjs`: native window and constrained IPC
- `library.cjs`: copied PDFs and atomic local state persistence
- `updates.cjs`: checked updates and save-before-restart behavior
- `renderer/`: the reader interface and browser-side PDF rendering
- `scripts/`: PDF.js resource preparation and release verification
- `test/`: unit, native Electron, and Windows installed-app tests, with local fixtures
- `.github/workflows/`: standalone CI and Windows release automation

This handoff is a source transfer, not a newly published application release.
